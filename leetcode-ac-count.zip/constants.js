export const STAR_ICON_CLASS_NAME = "favor-icon__2vM7 fa fa-star";
export const SOLVED_COUNT_CLASS_NAME = "solved-label__2sk4";
